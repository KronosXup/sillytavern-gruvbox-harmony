# Gruvbox Harmony 主题字体替换指南

> 改主题字体只需改两处：`@import` 链接 + `--font-*` 变量。改完保存 JSON 重新导入主题即可，不动任何布局。

---

## 一、找到要改的位置

用记事本/VSCode 打开主题 JSON（如 `Gruvbox-Harmony-Aqua.json`），搜 `---字体加载---` 这一节：

```css
/* ---字体加载--- */
@import url('https://cdn.jsdelivr.net/npm/@fontsource/jetbrains-mono@5.0.0/index.css');
@import url('https://cdn.jsdelivr.net/npm/@lobehub/webfont-harmony-sans-sc@1.0.0/css/index-full.css');
@import url('https://cdn.jsdelivr.net/npm/cn-fontsource-source-han-sans-sc-vf/font.css');

/* ---字体变量--- */
:root {
  --font-sans: 'HarmonyOS Sans SC', system-ui, sans-serif;
  --font-serif: 'HarmonyOS Sans SC', system-ui, sans-serif;
  --font-mono: 'JetBrains Mono', 'Cascadia Code', ui-monospace, Menlo, Consolas, 'Source Han Sans SC VF', monospace;
}
```

三个变量对应的用途：

| 变量 | 用在哪里 |
|------|---------|
| `--font-sans` | 正文、聊天、菜单、输入框、下拉选择、按钮等大多数文字 |
| `--font-serif` | 引号文 `<q>`、引用块 `<blockquote>` |
| `--font-mono` | 代码块、行内 code、hljs 高亮、katex 公式 |

### `--font-mono` 的降级逻辑

代码块字体按从左往右尝试，装上哪个用哪个：

| 位置 | 字体 | 作用 |
|------|------|------|
| 第 1 位 | `JetBrains Mono` | 英文等宽主力，代码缩进/运算符的对齐全靠它 |
| 第 2~5 位 | `Cascadia Code / ui-monospace / Menlo / Consolas` | 备选英文等宽，给没装 JB Mono 的系统兜底 |
| 第 6 位（最后） | `Source Han Sans SC VF`（思源黑体） | 中文 fallback，当英文等宽字体不包含某个汉字时顶上，真正中英 1:2 严格对齐 |

> 之前最后一位是 `HarmonyOS Sans SC`。它不是等宽字体，中英文混排时宽度会错位，所以换成了思源。

---

## 二、换成霞鹜文楷（示例）

### 1. 改 `@import`

替换为文楷 Screen（含 Mono 等宽变体，一个包全包）：

```css
@import url('https://cdn.jsdelivr.net/npm/lxgw-wenkai-screen-web@latest/style.css');
@import url('https://cdn.jsdelivr.net/npm/@fontsource/jetbrains-mono@5.0.0/index.css');
```

> 想用原版（带笔锋）就改成 `lxgw-wenkai-webfont@1.7.0/style.css`；想用 GB 版就 `lxgw-wenkai-gb-web@latest/style.css`。这些包同样自带 Mono 变体。

### 2. 改 `--font-*`

```css
:root {
  --font-sans: 'LXGW WenKai Screen', system-ui, sans-serif;
  --font-serif: 'LXGW WenKai Screen', system-ui, serif;
  --font-mono: 'JetBrains Mono', 'Cascadia Code', ui-monospace, Menlo, Consolas, 'LXGW WenKai Mono Screen', monospace;
}
```

> 文楷 Screen 用于正文、Mono Screen 是等宽变体用于代码块，同一个 CDN 包加载。

注意 family 名必须和 CDN 包里的 `font-family` 完全一致（区分大小写、空格），否则会回退到 system-ui。

---

## 三、常见字体 CDN 和 family 名对照

| 字体 | @import 链接 | family 名 |
|------|------------|----------|
| 霞鹜文楷屏幕版 | `lxgw-wenkai-screen-web@latest/style.css` | `LXGW WenKai Screen` |
| 霞鹜文楷等宽屏幕版 | 同上，一个包自带 | `LXGW WenKai Mono Screen` |
| 霞鹜文楷原版 | `lxgw-wenkai-webfont@1.7.0/style.css` | `LXGW WenKai` |
| 霞鹜文楷等宽原版 | 同上，一个包自带 | `LXGW WenKai Mono` |
| 霞鹜文楷 GB | `lxgw-wenkai-gb-web@latest/style.css` | `LXGW WenKai GB` |
| 霞鹜文楷等宽 GB | 同上，一个包自带 | `LXGW WenKai Mono GB` |
| 霞鹜文楷 Lite | `lxgw-wenkai-lite-webfont@1.1.0/style.css` | `LXGW WenKai Lite` |
| 霞鹜文楷 TC（繁中） | `lxgw-wenkai-tc-webfont@1.0.0/style.css` | `LXGW WenKai TC` |
| 思源黑体 | `cn-fontsource-source-han-sans-sc-vf/font.css` | `Source Han Sans SC VF` |
| HarmonyOS Sans SC | `@lobehub/webfont-harmony-sans-sc@1.0.0/css/index-full.css` | `HarmonyOS Sans SC`（默认） |

> 所有链接加前缀 `https://cdn.jsdelivr.net/npm/`。
> **思源黑体是真正的等宽支持字体**：中文方块严格等宽、英文 1/2 宽度，代码对齐效果好。主题默认 `--font-mono` 的 fallback 已使用它（代替 HarmonyOS）。

---

## 四、只改 `--font-mono` 不碰其他（需 no 新 @import）

主题默认 mono 中文本 fallback 从 HarmonyOS 改成了 Source Han Sans SC VF。若不想要它：

```css
--font-mono: 'JetBrains Mono', 'Cascadia Code', ui-monospace, Menlo, Consolas, monospace;
```

即删掉最后的 `'Source Han Sans SC VF'` 手动降级为系统等宽。

---

## 五、改完不生效的排查

1. **打开浏览器 F12 → Network**，看那些 CSS 是不是 200。404 就是链接写错了。
2. **Elements 选中 body**，看 Computed → `font-family` 显示的是不是你写的名字。如果是 `system-ui` 就是 family 名拼错了。
3. **主题没重新加载**：酒馆设置里点一次"重新加载主题"，或彻底重启酒馆。
4. **正文字体生效但下拉/输入框不生效**：v1.5.1+ 已 fix，所有表单元素显式用 `var(--font-sans)`。

---

## 六、关于布局

`font-family` 只影响字形，不参与盒模型计算（margin/padding/width 都不变），所以**改字体不会破坏任何布局**。

唯一例外：代码块的等宽对齐——如果 `--font-mono` 被换成比例字体，代码不再对齐。所以 `--font-mono` 建议永远保留一个等宽 fallback。主题默认沿用 JetBrains Mono（英文前半段都是真等宽），中文 fallback 改为思源黑体，代码块对齐没问题。

---

## 版本

- v1.5.1+ 表单元素显式使用 `var(--font-sans)`，下拉选项、输入框统一跟随主题字体
- v1.5.1+ `--font-mono` 中文 fallback 从 HarmonyOS → Source Han Sans SC VF（真等宽，代码对齐更可靠）
