﻿Gruvbox Themes - release-20260725
================================

Offline/  Harmony 完整版（含 Phosphor 图标补漏）× 5 色
Online/   轻量版 × 5 色

颜色: Aqua / Green / Orange / Pink / Purple

用法: 导入 SillyTavern → 用户设置 → 主题 → 导入 JSON

git tag: release-20260725
commit:  PC按钮交还ST原版 + 移动端布局 + PC头像/计数器
